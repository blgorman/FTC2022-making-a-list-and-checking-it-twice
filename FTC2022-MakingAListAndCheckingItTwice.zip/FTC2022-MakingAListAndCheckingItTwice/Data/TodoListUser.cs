﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace FTC2022_MakingAListAndCheckingItTwice.Data
{
    public class TodoListUser : IdentityUser
    {
        //do some custom fields here.
        //[StringLength(255)]
        //public string Passphrase { get; set; }
    }
}
