namespace FTC2022_MakingAListAndCheckingItTwice.Data
{
    public interface IUsersRolesService
    {
        Task EnsureUsersAndRoles();
    }
}