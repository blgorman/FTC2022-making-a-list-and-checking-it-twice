using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace FTC2022_MakingAListAndCheckingItTwice.Views.TodoList
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
